---
mission: 'It is centred around a fruitful commitment to awareness and advancements in the field of cybersecurity — an area that is often lacking in contemporary academic discourse in Pakistan. We aim to do the deed and raise that awareness, help our university and community by providing security solutions, and spread the fun by organising workshops and cybersecurity drills for the wider NUST student body. It is a journey of all-embracing implications, and we aim to do it in the best way possible..'

---

Cyber Security drills, workshops and more: The <span>NCSC</span> is a society heartily dedicated to the awareness of a key field that can't be ignored.



